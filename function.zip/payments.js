// lambda/payments.js
const AWS = require("aws-sdk");
const eb = new AWS.EventBridge();

exports.handler = async (event) => {
  // When invoked by EventBridge, event contains Records-like structure:
  const detail = event.detail || event.Records || null;

  // For demo: log the incoming event; pretend to charge/payment succeed
  console.log("Payment Lambda invoked. Event:", JSON.stringify(event));

  // In a real app: process payment gateway call here
  // Example: emit PaymentProcessed event

  if (
    event["detail-type"] === "OrderCreated" ||
    event.detailType === "OrderCreated"
  ) {
    const orderId =
      (event.detail && event.detail.orderId) ||
      (event.detail && event.detail[0] && event.detail[0].orderId);
    // emit PaymentProcessed
    await eb
      .putEvents({
        Entries: [
          {
            EventBusName: process.env.EVENT_BUS_NAME,
            Source: "payments",
            DetailType: "PaymentProcessed",
            Detail: JSON.stringify({
              orderId,
              status: "PAID",
              processedAt: new Date().toISOString(),
            }),
          },
        ],
      })
      .promise();
  }

  return { statusCode: 200, body: "ok" };
};
