// lambda/orders.js
const AWS = require("aws-sdk");
const { v4: uuidv4 } = require("uuid");

const ddb = new AWS.DynamoDB.DocumentClient();
const eb = new AWS.EventBridge();

const ORDERS_TABLE = process.env.ORDERS_TABLE;
const EVENT_BUS_NAME = process.env.EVENT_BUS_NAME;

exports.handler = async (event) => {
  const method =
    event.httpMethod ||
    (event.requestContext &&
      event.requestContext.http &&
      event.requestContext.http.method);

  if (method === "POST") {
    const body =
      typeof event.body === "string" ? JSON.parse(event.body) : event.body;
    const orderId = uuidv4();
    const item = {
      orderId,
      status: "CREATED",
      items: body.items || [],
      createdAt: new Date().toISOString(),
    };

    await ddb
      .put({
        TableName: ORDERS_TABLE,
        Item: item,
      })
      .promise();

    // emit event to EventBridge
    await eb
      .putEvents({
        Entries: [
          {
            EventBusName: EVENT_BUS_NAME,
            Source: "orders",
            DetailType: "OrderCreated",
            Detail: JSON.stringify({ orderId, items: item.items }),
          },
        ],
      })
      .promise();

    return {
      statusCode: 201,
      body: JSON.stringify(item),
    };
  }

  if (method === "GET") {
    // simple scan (for demo only)
    const resp = await ddb.scan({ TableName: ORDERS_TABLE }).promise();
    return {
      statusCode: 200,
      body: JSON.stringify(resp.Items || []),
    };
  }

  return { statusCode: 400, body: "Unsupported method" };
};
